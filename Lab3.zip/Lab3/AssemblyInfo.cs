﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Guid("710b6c60-3a67-4738-b004-cb1eaad32b72")]
[assembly: AssemblyCopyright("Copyright © Obshaga 2017")]
[assembly: AssemblyProduct("АТП")]
[assembly: AssemblyCompany("Obshaga")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyTitle("АТП")]
[assembly: AssemblyVersion("1.0.0.0")]
